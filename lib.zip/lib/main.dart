import 'package:flutter/material.dart';
import 'package:todo2/src/app.dart';

void main(){
  runApp(
      App()
  );
}